package com.example.clappybee.util

actual fun getPlatform(): Platform = Platform.Web