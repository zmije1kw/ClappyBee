package com.example.clappybee.domain

data class Bee(
    val x: Float,
    val y: Float,
    val radius: Float
)
