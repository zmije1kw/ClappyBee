package com.example.clappybee.domain

enum class GameStatus {
    Idle,
    Started,
    Over
}