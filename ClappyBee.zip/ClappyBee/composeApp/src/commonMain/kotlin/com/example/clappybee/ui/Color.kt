package com.example.clappybee.ui

import androidx.compose.ui.graphics.Color

val orange = Color(0xFFCB5C0C)